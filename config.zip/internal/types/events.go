package types

type Event struct {
	Name    string
	Handler interface{}
}
