package bot

import (
	"github.com/bwmarrin/discordgo"
	"github.com/kevinfinalboss/Void/commands/admin"
	"github.com/kevinfinalboss/Void/config"
	"github.com/kevinfinalboss/Void/events/guild"
	"github.com/kevinfinalboss/Void/internal/commands"
	"github.com/kevinfinalboss/Void/internal/database"
	"github.com/kevinfinalboss/Void/internal/events"
	"github.com/kevinfinalboss/Void/internal/logger"
)

type Bot struct {
	sessions     []*discordgo.Session
	config       *config.Config
	logger       *logger.Logger
	cmdHandler   *commands.Handler
	eventHandler *events.Handler
	db           *database.MongoDB
	guildHandler *guild.Handler
}

func New(cfg *config.Config, logger *logger.Logger) (*Bot, error) {
	db, err := database.NewMongoDB(cfg)
	if err != nil {
		return nil, err
	}

	return &Bot{
		config: cfg,
		logger: logger,
		db:     db,
	}, nil
}

func (b *Bot) Start() error {
	if b.config.Discord.Sharding.Enabled {
		return b.startSharded()
	}
	return b.startSingle()
}

func (b *Bot) startSingle() error {
	session, err := discordgo.New("Bot " + b.config.Discord.Token)
	if err != nil {
		return err
	}

	b.sessions = []*discordgo.Session{session}
	return b.setupSession(session, 0, 1)
}

func (b *Bot) startSharded() error {
	totalShards := b.config.Discord.Sharding.TotalShards
	b.sessions = make([]*discordgo.Session, totalShards)

	for i := 0; i < totalShards; i++ {
		session, err := discordgo.New("Bot " + b.config.Discord.Token)
		if err != nil {
			return err
		}

		b.sessions[i] = session
		if err := b.setupSession(session, i, totalShards); err != nil {
			return err
		}
	}

	return nil
}

func (b *Bot) setupSession(session *discordgo.Session, shardID, totalShards int) error {
	session.ShardID = shardID
	session.ShardCount = totalShards

	session.Identify.Intents = discordgo.IntentsAll

	if shardID == 0 {
		b.cmdHandler = commands.NewHandler(session, b.config, b.logger)
		b.eventHandler = events.NewHandler(session, b.config, b.logger)
		b.guildHandler = guild.NewHandler(b.db, b.logger)

		admin.SetDatabase(b.db)

		if err := b.cmdHandler.LoadCommands(); err != nil {
			return err
		}

		if err := b.eventHandler.LoadEvents(); err != nil {
			return err
		}
	}

	session.AddHandler(b.cmdHandler.HandleCommand)
	session.AddHandler(b.guildHandler.HandleGuildCreate)
	session.AddHandler(b.guildHandler.HandleGuildDelete)
	session.AddHandler(admin.HandleConfigButton)

	return session.Open()
}

func (b *Bot) Stop() error {
	if b.cmdHandler != nil {
		if err := b.cmdHandler.DeleteCommands(); err != nil {
			b.logger.Error("Error deleting commands: " + err.Error())
		}
	}

	if b.db != nil {
		if err := b.db.Close(); err != nil {
			b.logger.Error("Error closing MongoDB connection: " + err.Error())
		}
	}

	for _, session := range b.sessions {
		if session != nil {
			if err := session.Close(); err != nil {
				b.logger.Error("Error closing session: " + err.Error())
			}
		}
	}

	return nil
}
