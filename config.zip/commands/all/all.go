package all

import (
	_ "github.com/kevinfinalboss/Void/commands/admin"
	_ "github.com/kevinfinalboss/Void/commands/files"
	_ "github.com/kevinfinalboss/Void/commands/images"
	_ "github.com/kevinfinalboss/Void/commands/util"
	_ "github.com/kevinfinalboss/Void/commands/video"
	// Importe outros pacotes de comando aqui, se houver
)
