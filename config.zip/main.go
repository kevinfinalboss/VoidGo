package main

import (
	"log"
	"os"
	"os/signal"
	"syscall"

	"github.com/kevinfinalboss/Void/api/server"
	"github.com/kevinfinalboss/Void/config"
	"github.com/kevinfinalboss/Void/internal/bot"
	"github.com/kevinfinalboss/Void/internal/logger"
)

func main() {
	cfg, err := config.Load("config.yaml")
	if err != nil {
		log.Fatal("Error loading config:", err)
	}

	logger := logger.New(cfg.Logger)

	srv := server.NewServer()
	srv.SetupRoutes()
	go func() {
		if err := srv.Start(":8080"); err != nil {
			logger.Fatal("Failed to start server:", err)
		}
	}()

	bot, err := bot.New(cfg, logger)
	if err != nil {
		logger.Fatal("Failed to create bot:", err)
	}

	if err := bot.Start(); err != nil {
		logger.Fatal("Failed to start bot:", err)
	}

	sc := make(chan os.Signal, 1)
	signal.Notify(sc, syscall.SIGINT, syscall.SIGTERM, os.Interrupt)
	<-sc

	bot.Stop()
}
